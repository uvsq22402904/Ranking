#include "stdio.h"
#include "stdlib.h"

// Structure de données pour stocker une matrice en plein
struct matrice {
	int N;     // La taille
	float **V; // Les valeurs
};

// Alloue la mémoire nécessaire pour stocker une matrice carrée
// de taille "ma_taille" dans un "struct matrice"
struct matrice init_memoire(int ma_taille) {
	int i,j;
	struct matrice T;
	T.N = ma_taille;
	T.V = malloc(T.N*sizeof(float *));
	if (T.V==NULL) exit(1);
	for (i=0 ; i<T.N ; i=i+1) {
		T.V[i] = malloc(T.N*sizeof(float));
		if (T.V[i]==NULL) exit(2);
		for (j=0 ; j<T.N ; j++)
			T.V[i][j] = 0.0;
	}
	return T;
}

// Lit le fichier "nom_fic" qui contient une matrice,
// alloue la mémoire nécessaire et stocke la matrice
// dans un "struct matrice"
struct matrice lire_fichier(char *nom_fic) {
	int i,j;
	struct matrice T;
	FILE *F;
	F = fopen(nom_fic,"r");
	fscanf(F,"%d",&(T.N));
	T = init_memoire(T.N);
	for (i=0 ; i<T.N ; i++)
		for (j=0 ; j<T.N ; j++)
			fscanf(F,"%f",&(T.V[i][j]));
	fclose(F);
	return T;
}

// Affiche la matrice stockée dans le "struct matrice" "T"
void aff (struct matrice T) {
	int i,j;
	printf("%d\n",T.N);
	for (i=0 ; i<T.N ; i++) {
		for (j=0 ; j<T.N ; j++)
			printf(" %.0f",T.V[i][j]);
		printf("\n");
	}
}

// Programme principal
int main() {
	struct matrice T;
	T = lire_fichier("mat_1.txt");;
	aff (T);
	exit(0);
}

